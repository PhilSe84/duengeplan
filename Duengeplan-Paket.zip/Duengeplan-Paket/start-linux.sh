#!/bin/bash
cd "$(dirname "$0")"
clear
echo ""
echo "  ============================================"
echo "    Duengeplan - Natuerliche Mittel"
echo "  ============================================"
echo ""

if command -v python3 &>/dev/null; then
    echo "  Python3 gefunden!"
    echo "  Starte lokalen Server auf http://localhost:8000/"
    echo ""
    echo "  ZUM BEENDEN: Strg+C"
    echo ""
    sleep 2
    if command -v xdg-open &>/dev/null; then
        xdg-open "http://localhost:8000/Duengeplan.html" &
    elif command -v sensible-browser &>/dev/null; then
        sensible-browser "http://localhost:8000/Duengeplan.html" &
    fi
    python3 -m http.server 8000 --bind 127.0.0.1
else
    echo "  Python3 nicht gefunden."
    echo "  Oeffne Duengeplan.html direkt im Browser..."
    echo ""
    if command -v xdg-open &>/dev/null; then
        xdg-open "Duengeplan.html"
    elif command -v sensible-browser &>/dev/null; then
        sensible-browser "Duengeplan.html"
    else
        echo "  Bitte Duengeplan.html manuell im Browser oeffnen."
    fi
fi
