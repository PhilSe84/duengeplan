# Duengeplan – Natürliche Mittel

Offline-Tool für natürliches Düngen (Cannabis, Erde, 5–7 L Topf).

## Nutzung
- **Einfach:** Duengeplan.html im Browser öffnen
- **Empfohlen (Windows):** start-windows.bat doppelklicken
- **Empfohlen (Linux):** chmod +x start-linux.sh && ./start-linux.sh

Der lokale Server sorgt dafür, dass der Fortschritt (Inventar, Häkchen) zuverlässig gespeichert wird.

## Features
- 21+ Zutaten mit Dosierung, Reifezeit, pH-Wirkung
- Leitfaden: Jauche, FFJ, Tee, Fermentieren, Trocknen
- Schädlingsbekämpfung (Mehltau nach Schweregrad, Blattsprays)
- Wasser-Guide, Wärmebehandlung
- Inventar & Ranking (was zuerst besorgen)
- Mix-Schema (was passt zusammen)

## Datenschutz
100 % offline. Keine Cloud, kein Tracking, keine externen Links.
Fortschritt nur lokal im Browser (localStorage).

## Lizenz
Frei nutzbar, veränderbar, weitergebbar.
