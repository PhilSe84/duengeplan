@echo off
title Duengeplan
cd /d "%~dp0"
cls
echo.
echo  ============================================
echo    Duengeplan - Natuerliche Mittel
echo  ============================================
echo.

set PYTHON=
where python  >nul 2>nul && set PYTHON=python
if not defined PYTHON where python3 >nul 2>nul && set PYTHON=python3
if not defined PYTHON where py      >nul 2>nul && set PYTHON=py

if defined PYTHON (
    echo  Python gefunden: %PYTHON%
    echo  Starte lokalen Server auf http://localhost:8000/
    echo.
    echo  ZUM BEENDEN: Strg+C oder Fenster schliessen
    echo.
    timeout /t 2 /nobreak >nul
    start "" http://localhost:8000/Duengeplan.html
    %PYTHON% -m http.server 8000 --bind 127.0.0.1
) else (
    echo  Python nicht gefunden.
    echo  Oeffne Duengeplan.html direkt im Browser...
    echo.
    echo  HINWEIS: Ohne lokalen Server kann dein Browser
    echo  den Fortschritt evtl. nicht speichern.
    echo  Empfehlung: Python installieren von python.org
    echo.
    timeout /t 4 /nobreak >nul
    start "" "Duengeplan.html"
)
pause
